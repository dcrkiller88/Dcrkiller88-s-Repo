#-*- coding: utf-8 -*-
import xbmc, xbmcgui, os
import utils

dialog = xbmcgui.Dialog()

xbmc.sleep(5000)
updatechk, versie = utils.checkUpdate()
if updatechk == 'update':
	yes_pressed = dialog.yesno("[COLOR red]KAOSbox Update[/COLOR]", '[COLOR yellow]Er staat een nieuwe KAOSbox update voor u klaar[/COLOR]', '[COLOR white]Wilt u uw KAOSbox nu bijwerken?[/COLOR]', '', yeslabel='JA', nolabel='LATER GRAAG')
	if yes_pressed:
                	xbmc.executebuiltin("ActivateWindow(10001,plugin://script.kaosboxtools/,return)")

	else:
			dialog.ok('[COLOR red]KAOSbox Update[/COLOR]', '[COLOR white]U kunt KAOSbox bijwerken de volgende keer dat u de box opnieuw opstart.[/COLOR]','','')


