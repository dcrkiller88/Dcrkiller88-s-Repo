#-*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import utils



addon_id = 'script.kaosboxtools'
ADDON = utils.ADDON
AddonID = 'script.kaosboxtools'
AddonTitle = "KAOSbox Tools"


dialog = xbmcgui.Dialog()
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "4.6.0"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "KAOSbox Tools"            
BASEURL = "http://www.kaosbox.tv"
H = 'http://'
thumbnailPath = xbmc.translatePath('special://thumbnails');
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'script.schoonmaak')
mediaPath = os.path.join(addonPath, 'media')
databasePath = xbmc.translatePath('special://database')
color1 = utils.color1
color2 = utils.color2

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi

def resolver_settings():
    import urlresolver
    urlresolver.display_settings()

def INDEX():
    update, updateversie = utils.checkUpdate()
    updatetxt = "KAOSbox update beschikbaar: %s" % (updateversie) if update == "update" else "U heeft de laatste KAOSbox Update"    
    addDir('%s' % updatetxt,'https://www.kaosbox.tv/updates/default.zip',5,ART+'kaosboxdownload.png',FANART,'')
    addDir('','','',ART+'kaosboxdownload.png',FANART,'')
    addDir('[COLOR yellow]KAOSbox Onderhoud[/COLOR]',BASEURL,12,ART+'kaosboxdownload.png',FANART,'')
    addDir('[COLOR yellow]KAOSbox Fixes/Downloads en Goodies[/COLOR]',BASEURL,3,ART+'kaosboxdownload.png',FANART,'')
    if xbmc.getCondVisibility('System.HasAddon("service.openelec.settings")') + xbmc.getCondVisibility('System.HasAddon("service.libreelec.settings")'):
    	addItem('[COLOR yellow]KAOSbox Raspberry Pi Tools[/COLOR]',BASEURL,15,os.path.join(mediaPath, "kaosboxdownload.png"))
    addItem('[COLOR orange]URLResolver settings openen[/COLOR]',BASEURL,7,os.path.join(mediaPath, "kaosboxdownload.png"))
    addItem('[COLOR red]Over KAOSbox[/COLOR]',BASEURL,8,os.path.join(mediaPath, "kaosboxdownload.png"))
    setView('movies', 'MAIN')


def KAOSBOXTOOLS():
    addItem('Cache Legen',BASEURL,9,os.path.join(mediaPath, "kaosboxdownload.png"))
    addItem('Thumbnails Verwijderen',BASEURL,10,os.path.join(mediaPath, "kaosboxdownload.png"))
    addItem('Installatie bestanden verwijderen',BASEURL,11,os.path.join(mediaPath, "kaosboxdownload.png"))
    if int(utils.kodiver) <= 16.7:  
	    addItem('Verwijder addons.db',BASEURL,14,os.path.join(mediaPath, "kaosboxdownload.png"))
    elif int(utils.kodiver) > 16.7:
	    addItem('Inschakelen Add-ons (Kodi 17 Krypton)',BASEURL,4,os.path.join(mediaPath, "kaosboxdownload.png"))
    addItem('Wat is mijn Kodi Versie?',BASEURL,13,os.path.join(mediaPath, "kaosboxdownload.png"))
    setView('movies', 'MAIN')


def MAINTENANCE():
    link = OPEN_URL('http://bit.ly/1UvWE4J').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,5,ART+'kaosboxdownload.png',FANART,description)
    setView('movies', 'MAIN')


def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def KODIVERSION(url): xbmc_version=xbmc.getInfoLabel("System.BuildVersion"); version=xbmc_version[:4]; print version; dialog.ok(AddonTitle, "Kodi Versie is : %s" % version)


def removeAddonsDatabase():
    dbList = os.listdir(databasePath)
    dbAddons = []
    removed = True
    for file in dbList:
        if re.findall('Addons(\d+)\.db', file):
            dbAddons.append(file)
    for file in dbAddons:
        dbFile = os.path.join(databasePath, file)
        try:
            os.unlink(dbFile)
        except:
            removed = False
    if removed:
        dialog.ok("KAOSbox Onderhoud", "Herstart uw systeem om addons database weer op te bouwen")
    else:
        dialog.ok("KAOSbox Onderhoud", "Het verwijderen is mislukt!", "U zou dit handmatig moeten doen")


#######################################################################
#						Work Functions
#######################################################################
def setupCacheEntries():
    entries = 5 #make sure this refelcts the amount of entries you have
    dialogName = ["MP3 Streams", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.audio.mp3streams/temp_dl", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries


def clearCache():
    
    if os.path.exists(cachePath)==True:    
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                if dialog.yesno("KAOSbox Onderhoud", str(file_count) + " bestanden gevonden", "Weet je zeker dat je ze wil verwijderen?"):
                
                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if os.path.exists(tempPath)==True:    
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:

                if dialog.yesno("KAOSbox Onderhoud", str(file_count) + " bestanden gevonden", "Weet je zeker dat je ze wil verwijderen?"):
                    for f in files:
                        try:
                            if (f == "xbmc.log" or f == "xbmc.old.log"): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:


                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:


                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass    
                
    cacheEntries = setupCacheEntries()
                                         
    for entry in cacheEntries:
        clear_cache_path = xbmc.translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:    
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:


                    if dialog.yesno("Raw Manager",str(file_count) + "%s cache files found"%(entry.name), "Do you want to delete them?"):
                        for f in files:
                            os.unlink(os.path.join(root, f))
                        for d in dirs:
                            shutil.rmtree(os.path.join(root, d))
                            
                else:
                    pass
                


    dialog.ok("KAOSbox Onderhoud", "Je cache is geleegd!")

    
def deleteThumbnails():
    if os.path.exists(thumbnailPath)==True:  
            if dialog.yesno("KAOSbox Onderhoud", "Deze optie verwijderd alle thumbnails", "Weet u zeker dat u deze wilt verwijderen?"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass
    else:
        pass
    
    text13 = os.path.join(databasePath,"Textures13.db")
    try:
        os.unlink(text13)
    except:
        try:
            dbcon = sqlite3.connect(text13)
            dbcur = dbcon.cursor()
            dbcur.execute('DROP TABLE IF EXISTS path')
            dbcur.execute('VACUUM')
            dbcon.commit()
            dbcur.execute('DROP TABLE IF EXISTS sizes')
            dbcur.execute('VACUUM')
            dbcon.commit()
            dbcur.execute('DROP TABLE IF EXISTS texture')
            dbcur.execute('VACUUM')
            dbcon.commit()
            dbcur.execute("""CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))"""
                          )
            dbcon.commit()
            dbcur.execute("""CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)"""
                          )
            dbcon.commit()
            dbcur.execute("""CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))"""
                          )
            dbcon.commit()
        except:
            pass
        
    dialog.ok("KAOSbox Onderhoud", "Herstart uw systeem om de thumbnail map weer op te bouwen")
	        
def purgePackages():
    
    purgePath = xbmc.translatePath('special://home/addons/packages')

    for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
    if dialog.yesno("KAOSbox Onderhoud", "%d packages gevonden."%file_count, "Wil je ze verwijderen?"):  
        for root, dirs, files in os.walk(purgePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:            
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))

                dialog.ok("KAOSbox Onderhoud", "Alle Packages zijn verwijderd.")
            else:

                dialog.ok("KAOSbox Onderhoud", "Geen Packages om te verwijderen.")





#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def facebook():
    TextBoxes('KAOSbox Install', '[COLOR=red]KAOSbox - Home Entertainment Redefined[/COLOR]\nEindelijk een gratis no-nonsense plug en play media systeem voor je Raspberry Pi, Hummingboard/Cubox-i, Android en Windows media box!\n\nVoor meer informatie kijk op www.kaosbox.tv')

        

def wizard(name,url):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib)
    if os.path.exists(lib):
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp = xbmcgui.DialogProgress()
        dp.create("Uw systeem wordt nu bijgewerkt.",'', 'Wacht geduldig af tot volgende venster verschijnt.')
        dp.update(0,"", "ZIP wordt uitgepakt - even geduld")
        print '======================================='
        print addonfolder
        print '======================================='
        extract.all(lib,addonfolder,dp)
        dp.close()
        try: os.remove(lib)
        except: pass        
	if int(utils.kodiver) > 16.7:  
	        utils.enableAddons(melding=False)
        dialog.ok("DOWNLOAD is voltooid", 'Om de aanpassingen voor KAOSbox toe te passen moet kodi geforceerd worden gesloten', 'om kodi geforceerd te sluiten. klik je op OK')
        if int(utils.kodiver) > 16.7:  
	        utils.enableAddons(melding=False)
        xbmc.sleep(5000)
        killxbmc()
      

def killxbmc():
    myplatform = platform()
    try: os._exit(1)
    except: pass
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.cemc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.cemc_pro')
        except: pass
        try: os.system('adb shell am force-stop com.semperpax.spmc16') 
        except: pass
        try: os.system('adb shell am force-stop org.lodi.mobi') 
        except: pass
        try: os.system('adb shell am force-stop com.perfectzoneproductions.jesusboxmedia')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc') 
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass
        try: os.system('adb shell kill org.xbmc.kodi')
        except: pass
        try: os.system('adb shell kill org.kodi')
        except: pass
        try: os.system('adb shell kill org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell kill org.xbmc')
        except: pass
        try: os.system('adb shell kill com.semperpax.spmc16')
        except: pass
        try: os.system('adb shell kill com.semperpax')
        except: pass
        try: os.system('adb shell kill com.perfectzoneproductions.jesusboxmedia')
        except: pass
        try: os.system('adb shell kill org.xbmc.cemc')
        except: pass
        try: os.system('adb shell kill org.xbmc.cemc_pro')
        except: pass
        try: os.system('adb shell kill org.lodi.mobi')
        except: pass
        try: os.system('adb shell kill com.semperpax')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc.kodi());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.kodi());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
        except: pass
        try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
        except: pass
        dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "We hebben gedetecteerd dat er gebruik gemaakt word van Android, U ", "[COLOR=yellow][B]MOET[/COLOR][/B] kodi geforceerd sluiten. [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.","Of proces be�indigen met taakbeheer (Als je het niet zeker weet haal de stroom van de speler af).")
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill SMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im SMC.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.","gebruik taak beheer en geen ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.","het apparaat kon niet worden gedetecteerd dus verwijder de stroom kabel en start opnieuw.")

def platform():
    if xbmc.getCondVisibility('system.platform.android'): return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'): return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'): return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'): return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'): return 'ios'



def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
      
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        

if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==2:
        BUILDMENU()

elif mode==3:
        MAINTENANCE()
		
elif mode==4:
        utils.enableAddons(melding=True)
	
elif mode==5:
        wizard(name,url)

elif mode==7:
        resolver_settings()

elif mode==8:
       facebook()

elif mode==9:
       clearCache()
        
elif mode==10:
        deleteThumbnails()

elif mode==11:
	purgePackages()

elif mode==12:        
	KAOSBOXTOOLS()    
	
elif mode==13:        
	KODIVERSION(url)
	
elif mode==14:        
	removeAddonsDatabase()

elif mode==15:        
	xbmc.executebuiltin("RunAddon(script.kaosboxrpitools)")

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))