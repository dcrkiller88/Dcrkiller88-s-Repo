import urllib, urllib2, cookielib, os
import xbmc, xbmcaddon, xbmcgui

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

headers = {'User-Agent': USER_AGENT,
           'Accept': '*/*',
           'Connection': 'keep-alive'}

dialog = xbmcgui.Dialog()
kodiver = xbmc.getInfoLabel("System.BuildVersion").split(".")[0]
ADDON=xbmcaddon.Addon(id='script.kaosboxtools')
versieurl = "https://www.kaosbox.tv/versie.txt"
profileDir = ADDON.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
versietxt = xbmc.translatePath(os.path.join('special://home/userdata','versie.txt'))
color1 = "yellow"
color2 = "yellow"

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

urlopen = urllib2.urlopen
cj = cookielib.LWPCookieJar(xbmc.translatePath(cookiePath))
Request = urllib2.Request

if cj != None:
    if os.path.isfile(xbmc.translatePath(cookiePath)):
        try:
            cj.load()
        except:
            try:
                os.remove(xbmc.translatePath(cookiePath))
                pass
            except:
                pass
    cookie_handler = urllib2.HTTPCookieProcessor(cj)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
else:
    opener = urllib2.build_opener()

urllib2.install_opener(opener)


def getHtml2(url):
    req = Request(url)
    response = urlopen(req, timeout=60)
    data = response.read()
    response.close()
    return data


def postHtml(url, form_data={}, headers={}, compression=True, NoCookie=None):
    _user_agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 ' + \
                  '(KHTML, like Gecko) Chrome/13.0.782.99 Safari/535.1'
    req = urllib2.Request(url)
    if form_data:
        form_data = urllib.urlencode(form_data)
        req = urllib2.Request(url, form_data)
    req.add_header('User-Agent', _user_agent)
    for k, v in headers.items():
        req.add_header(k, v)
    if compression:
        req.add_header('Accept-Encoding', 'gzip')
    response = urllib2.urlopen(req, timeout=30)
    data = response.read()
    if not NoCookie:
        try:
            cj.save(cookiePath)
        except: pass
    response.close()
    return data


        
def checkUpdate(onlycurrent=False):
    if os.path.isfile(versietxt):
        file = open(versietxt, 'r')
        versie = file.read()
        file.close()
        if onlycurrent:
            return versie, ''
        try: updatev = getHtml2(versieurl)
        except: return 'noupdate', versie
        if int(updatev) > int(versie):
            return 'update', updatev
        else:
            return 'noupdate', versie
    else:
        return 'notinstalled', ''
    

def enableAddons(melding=None, update=True):
    if kodiver > 16.5:
        try:    from sqlite3 import dbapi2 as database
        except: from pysqlite2 import dbapi2 as database
        
        db_dir = xbmc.translatePath("special://profile/Database")
        db_path = os.path.join(db_dir, 'Addons27.db')
        conn = database.connect(db_path)
        conn.text_factory = str
        
        addonfolder=xbmc.translatePath(os.path.join('special://home','addons'))
        contents = os.listdir(addonfolder)
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)', ((val,) for val in contents))
        conn.commit()
        if update:
            xbmc.executebuiltin('UpdateAddonRepos()')
            xbmc.executebuiltin('UpdateLocalAddons()')
        if melding:
            dialog.ok("[COLOR yellow][B]Addons enabled[/COLOR][/B]", 'Alle addons staan nu aan!')