import xbmcaddon
MainBase = 'https://goo.gl/BLF7o4'
addon = xbmcaddon.Addon('plugin.video.MegaBoxTV')