#-*- coding: utf-8 -*-

import xbmc, xbmcgui, os
import utils

dialog = xbmcgui.Dialog()
ADDON = utils.ADDON

xbmc.sleep(3000)

if ADDON.getSetting('install17') == 'true':
	utils.enableAddons()
	xbmc.executebuiltin("ReloadSkin()")
	currentskin = xbmc.getSkinDir()
	xbmc.log("current: " + currentskin, level=xbmc.LOGNOTICE)
	if 'skin.estuary' in currentskin:
		newskin = ADDON.getSetting('skin17')
		xbmc.log("new: " + newskin, level=xbmc.LOGNOTICE)
		import skinSwitch
		skinSwitch.swapSkins(newskin)
		x = 0
		xbmc.sleep(1000)
		while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
			x += 1
			xbmc.sleep(200)

		if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
			xbmc.executebuiltin('SendClick(11)')
		xbmc.log("skin has been set", level=xbmc.LOGNOTICE)
		ADDON.setSetting(id='skin17', value="")
	ADDON.setSetting(id='install17', value="")
