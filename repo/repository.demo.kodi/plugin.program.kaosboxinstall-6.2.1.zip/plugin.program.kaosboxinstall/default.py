#-*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import utils


addon_id = 'plugin.program.kaosboxinstall'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID = 'plugin.program.kaosboxinstall'
AddonTitle = "KAOSbox Install"
dialog = xbmcgui.Dialog()
thumbdir = xbmc.translatePath('special://thumbnails')
cachePath = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath = xbmc.translatePath('special://temp')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "5.0.0"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails')
PATH = "KAOSbox Install"            
BASEURL = "http://www.kaosbox.tv"
H = 'http://'
addonPath = os.path.join(os.path.join(xbmc.translatePath('special://home'), 'addons'),'script.schoonmaak')
mediaPath = os.path.join(addonPath, 'media')
guisettings = xbmc.translatePath(os.path.join('special://home/userdata','guisettings.xml'))


def INDEX():
	addDir('KAOSbox Installeren',BASEURL,2,ART+'kaosboxdownload.png',FANART,'')
	addDir('KAOSbox Fixes/Downloads en Goodies',BASEURL,3,ART+'kaosboxdownload.png',FANART,'')
	addDir('Schone Installatie (Fabrieksinstellingen)','url',6,ART+'kaosboxdownload.png',FANART,'')
	addDir('','','',ART+'kaosboxdownload.png',FANART,'')
	addItem('[COLOR yellow]Over KAOSbox[/COLOR]',BASEURL,8,os.path.join(mediaPath, "kaosboxdownload.png"))
	setView('movies', 'MAIN')

def BUILDMENU():
	if int(utils.kodiver) <= 16.7:		  
			addItem('Installatie KAOSbox 2017','http://bit.ly/2kbr9hm',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Installatie XXX Pack (+18)','http://bit.ly/1pmtLvQ',5,os.path.join(mediaPath, "kaosboxdownload.png"))			
			addItem('[COLOR red]- [/COLOR][COLOR yellow][ Backup locatie ][/COLOR][COLOR red] -[/COLOR]','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Installatie KAOSbox 2017 (Backup Locatie)','http://bit.ly/2oFsT9m',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('','',5,os.path.join(mediaPath, "kaosboxdownload.png"))		  
	elif int(utils.kodiver) > 16.7:
			addItem('Installatie KAOSbox 2017','http://bit.ly/2l4nB5s',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Installatie XXX Pack (+18)','http://bit.ly/1pmtLvQ',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('[COLOR red]- [/COLOR][COLOR yellow][ Backup locatie ][/COLOR][COLOR red] -[/COLOR]','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Installatie KAOSbox 2017 (Backup Locatie)','http://bit.ly/2oFqYSc',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
	if xbmc.getCondVisibility('System.HasAddon("service.openelec.settings")') + xbmc.getCondVisibility('System.HasAddon("service.libreelec.settings")') and int(utils.kodiver) > 16.7:
			addItem('[COLOR red]- [/COLOR][COLOR yellow][ Raspberry Pi ][/COLOR][COLOR red] -[/COLOR]','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Installatie KAOSbox 2017 (geoptimaliseerd voor Raspberry Pi)','http://bit.ly/2scmZhE',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('','',5,os.path.join(mediaPath, "kaosboxdownload.png"))		
	if xbmc.getCondVisibility('System.HasAddon("service.openelec.settings")') + xbmc.getCondVisibility('System.HasAddon("service.libreelec.settings")'):
			addItem('[COLOR red]- [/COLOR][COLOR yellow][ Optioneel: Raspberry Pi optimalisatie bestanden ][/COLOR][COLOR red] -[/COLOR]','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Alleen voor de niet geoptimaliseerde KAOSbox 2017 Installatie','http://bit.ly/2qPTsdE',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('','',5,os.path.join(mediaPath, "kaosboxdownload.png"))		  
	if int(utils.kodiver) > 16.7:	           
			addItem('[COLOR red]- [/COLOR][COLOR yellow][ Tools ][/COLOR][COLOR red] -[/COLOR]','',5,os.path.join(mediaPath, "kaosboxdownload.png"))
			addItem('Inschakelen alle Add-ons',BASEURL,4,os.path.join(mediaPath, "kaosboxdownload.png"))      
	setView('movies', 'MAIN')



def MAINTENANCE():
	link = OPEN_URL('http://bit.ly/1UvWE4J').replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
	for name,url,iconimage,fanart,description in match:
		addDir(name,url,5,ART+'kaosboxdownload.png',FANART,description)
	setView('movies', 'MAIN')


def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
	WINDOW=10147
	CONTROL_LABEL=1
	CONTROL_TEXTBOX=5
	def __init__(self,*args,**kwargs):
	  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
	  self.win=xbmcgui.Window(self.WINDOW) # get window
	  xbmc.sleep(500) # give window time to initialize
	  self.setControls()
	def setControls(self):
	  self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
	  try: f=open(announce); text=f.read()
	  except: text=announce
	  self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
	  return
  TextBox()

def facebook():
	TextBoxes('KAOSbox Install', '[COLOR=red]KAOSbox - Home Entertainment Redefined[/COLOR]\nEindelijk een gratis no-nonsense plug en play media systeem voor je Raspberry Pi, Hummingboard/Cubox-i, Android en Windows media box!\n\nVoor meer informatie kijk op www.kaosbox.tv')

		

def wizard(name,url):
	path = xbmc.translatePath(os.path.join('special://home/','temp'))
	if not os.path.exists(path):
		os.makedirs(path)	
	lib=os.path.join(path, name+'.zip')
	try:
	   os.remove(lib)
	except:
	   pass
	downloader.download(url, lib)
	if os.path.exists(lib):
		addonfolder = xbmc.translatePath(os.path.join('special://','home'))
		xbmc.sleep(2000)
		dp = xbmcgui.DialogProgress()
		dp.create("Uw systeem wordt nu bijgewerkt.",'', 'Wacht geduldig af tot volgende venster verschijnt.')
		dp.update(0,"", "De bestanden worden uitgepakt - even geduld!")

		gelukt = extract.all(lib,addonfolder,dp)
		dp.close()
		try: os.remove(lib)
		except: pass	

		if gelukt:
			removefolder(thumbdir)
			removefolder(cachePath)
			removefolder(tempPath)
			if int(utils.kodiver) > 16.7:
				ADDON.setSetting(id='install17', value="true")
				getSkin()
			dialog.ok("DOWNLOAD is voltooid", 'Om de aanpassingen voor KAOSbox toe te passen moet kodi geforceerd worden gesloten', 'om kodi geforceerd te sluiten. klik je op OK')
			killxbmc()
		else:
			dialog.ok("Uitpakken is mislukt", 'Probeer het nog een keer.')
	
	
def removefolder(map):
	if os.path.exists(map)==True:
		for root, dirs, files in os.walk(map, topdown=False):
			for name in files:
				try: os.remove(os.path.join(root, name))
				except: pass
			for name in dirs:
				try: shutil.rmtree(os.path.join(root, name), ignore_errors=True, onerror=None)
				except: pass
		try: shutil.rmtree(map)
		except: pass
	  
def getSkin():
	with open(guisettings) as f:
		guitxt = f.read()
	match = re.compile('<lookandfeel>.+?<ski.+?>(.+?)</skin>', re.DOTALL | re.IGNORECASE).findall(guitxt)
	xbmc.log('match' + str(match), level=xbmc.LOGNOTICE)
	if match:
		skin = match[0]
		ADDON.setSetting(id='skin17', value=skin)
	

def FRESHSTART(params):
	yes_pressed = dialog.yesno("[COLOR yellow][B]Schone Install[/COLOR][/B]", '[COLOR red]Hiermee verwijder je alles in KAOSbox[/COLOR]', '[COLOR snow]Weet u zeker dat u hiermee door wilt gaan?[/COLOR]', '', yeslabel='JA', nolabel='NEE')
	if yes_pressed:
		excludes = ['plugin.program.kaosboxinstall','repository.kaosbox2']
		xbmcdir = xbmc.translatePath('special://home/')
		xbmcdir=os.path.abspath(xbmcdir)
		for root, dirs, files in os.walk(xbmcdir, topdown=True):
			dirs[:] = [d for d in dirs if d not in excludes]
			for name in files:
				try: os.remove(os.path.join(root, name))
				except: pass
			for name in dirs:
				if name not in ["addons", "addon_data", "userdata"]:
					try: shutil.rmtree(os.path.join(root, name), ignore_errors=True, onerror=None)
					except: pass
		killxbmc()


def killxbmc():
	myplatform = platform()
	try: os._exit(1)
	except: pass
	print "Platform: " + str(myplatform)
	if myplatform == 'osx': # OSX
		print "############   try osx force close  #################"
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.",'')
	elif myplatform == 'linux': #Linux
		print "############   try linux force close  #################"
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.",'')
	elif myplatform == 'android': # Android  
		print "############   try android force close  #################"
		try: os.system('adb shell am force-stop org.xbmc.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.cemc')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.cemc_pro')
		except: pass
		try: os.system('adb shell am force-stop com.semperpax.spmc16') 
		except: pass
		try: os.system('adb shell am force-stop org.lodi.mobi') 
		except: pass
		try: os.system('adb shell am force-stop com.perfectzoneproductions.jesusboxmedia')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.xbmc') 
		except: pass
		try: os.system('adb shell am force-stop org.xbmc')
		except: pass
		try: os.system('adb shell kill org.xbmc.kodi')
		except: pass
		try: os.system('adb shell kill org.kodi')
		except: pass
		try: os.system('adb shell kill org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell kill org.xbmc')
		except: pass
		try: os.system('adb shell kill com.semperpax.spmc16')
		except: pass
		try: os.system('adb shell kill com.semperpax')
		except: pass
		try: os.system('adb shell kill com.perfectzoneproductions.jesusboxmedia')
		except: pass
		try: os.system('adb shell kill org.xbmc.cemc')
		except: pass
		try: os.system('adb shell kill org.xbmc.cemc_pro')
		except: pass
		try: os.system('adb shell kill org.lodi.mobi')
		except: pass
		try: os.system('adb shell kill com.semperpax')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc.kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.kodi());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
		except: pass
		try: os.system('Process.killProcess(android.os.Process.org.xbmc());')
		except: pass
		dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "We hebben gedetecteerd dat er gebruik gemaakt word van Android, U ", "[COLOR=yellow][B]MOET[/COLOR][/B] kodi geforceerd sluiten. [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.","Of proces be�indigen met taakbeheer (Als je het niet zeker weet haal de stroom van de speler af).")
	elif myplatform == 'windows': # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill SMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im SMC.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.","gebruik taak beheer en geen ALT F4")
	else: #ATV
		print "############   try atv force close  #################"
		try: os.system('killall AppleTV')
		except: pass
		print "############   try raspbmc force close  #################" #OSMC / Raspbmc
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		dialog.ok("[COLOR=red][B]WAARSCHUWING  !!![/COLOR][/B]", "Als je dit bericht ziet is het geforceerd sluiten", "mislukt. Sluit kodi geforceerd [COLOR=lime]NIET VIA[/COLOR] het menu afsluiten.","het apparaat kon niet worden gedetecteerd dus verwijder de stroom kabel en start opnieuw.")

def platform():
	if xbmc.getCondVisibility('system.platform.android'): return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'): return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'): return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'): return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'): return 'ios'



def addItem(name,url,mode,iconimage):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

		  
		
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param
def addDir(name,url,mode,iconimage,fanart,description):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
		liz.setProperty( "Fanart_Image", fanart )
		if mode==5 :
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		else:
			ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
	  
					  
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:		
		mode=int(params["mode"])
except:
		pass
try:		
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:		
		description=urllib.unquote_plus(params["description"])
except:
		pass
		
		
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
		

if mode==None or url==None or len(url)<1:
		INDEX()

elif mode==2:
		BUILDMENU()

elif mode==3:
		MAINTENANCE()
		
		
elif mode==4:
		utils.enableAddons(melding=True)
	
elif mode==5:
		wizard(name,url)

elif mode==6:		
	FRESHSTART(params)

	
elif mode==8:
	   facebook()

			
xbmcplugin.endOfDirectory(int(sys.argv[1]))
