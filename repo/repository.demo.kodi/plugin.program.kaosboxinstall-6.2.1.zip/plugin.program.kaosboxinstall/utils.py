import urllib, urllib2, os
import xbmc, xbmcaddon, xbmcgui

dialog = xbmcgui.Dialog()

kodiver = xbmc.getInfoLabel("System.BuildVersion").split(".")[0]
ADDON=xbmcaddon.Addon(id='plugin.program.kaosboxinstall')
      
def enableAddons(melding=None, update=True):
    if kodiver > 16.5:
        try:    from sqlite3 import dbapi2 as database
        except: from pysqlite2 import dbapi2 as database
        
        db_dir = xbmc.translatePath("special://profile/Database")
        db_path = os.path.join(db_dir, 'Addons27.db')
        conn = database.connect(db_path)
        conn.text_factory = str
        
        addonfolder=xbmc.translatePath(os.path.join('special://home','addons'))
        contents = os.listdir(addonfolder)
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)', ((val,) for val in contents))
        conn.commit()
        if update:
            xbmc.executebuiltin('UpdateAddonRepos()')
            xbmc.executebuiltin('UpdateLocalAddons()')
        if melding:
            dialog.ok("[COLOR yellow][B]Addons enabled[/COLOR][/B]", 'Alle addons staan nu aan!')
    